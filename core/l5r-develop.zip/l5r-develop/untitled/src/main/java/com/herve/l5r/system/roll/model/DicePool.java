package com.herve.l5r.system.roll.model;

public interface DicePool {
    int keptDice();
    int modifier();
    int diceToRoll();
}
