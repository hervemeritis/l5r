package com.herve.l5r.system.model.avantage;

public interface AvantageDefinition {

    String description();
    String name();


}
