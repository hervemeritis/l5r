package com.herve.l5r.system.model.school;

import com.herve.l5r.system.roll.model.competence.CompetenceModifier;

public interface RankSchool {
    int rank();

    String name();
}
