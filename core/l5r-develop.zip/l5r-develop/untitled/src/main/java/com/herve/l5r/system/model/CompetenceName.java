package com.herve.l5r.system.model;

import java.util.function.Function;

public enum CompetenceName {
    IAJUSTSU;
}
