package com.herve.l5r.system.model;

public enum Emphasis {
    KATANA,EVALUATION,CONCENTRATION,NO_EMPHASIS_KNOWN
}
