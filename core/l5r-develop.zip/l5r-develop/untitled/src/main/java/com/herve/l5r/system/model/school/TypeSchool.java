package com.herve.l5r.system.model.school;

public enum TypeSchool {
    BUSHI, SHUGENJA, COURTISAN
}
